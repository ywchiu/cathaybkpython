import scrapy
from bs4 import BeautifulSoup
from cathay.items import CathayItem
from scrapy.spiders import CrawlSpider, Rule
from scrapy.linkextractors import LinkExtractor
from urlparse import urljoin

class CathayCrawler(CrawlSpider):
    name = 'cathay'
    start_urls = [
				  'https://www.cathayholdings.com/bank/'
				  ]
    rules = [
	    Rule(LinkExtractor(allow=(
								  'https://www.cathayholdings.com/bank/.*$'
		)), callback='parse_list', follow=True)
	]
    def parse_list(self, response):        
        #domain = response.url
        res = BeautifulSoup(response.body)
        title = ''
        if len(res.select('title')) >0:
            title = res.select('title')[0].text
        for news in res.select('a'):
            #print news.select('h1')[0].text
            cathayitem = CathayItem()
            cathayitem['from_title'] = title
            cathayitem['from_url'] = response.url
            cathayitem['to_linkname'] = news.text
            cathayitem['to_url'] = urljoin(response.url ,news['href'])
            return cathayitem
            #yield scrapy.Request(domain + news.select('a')[0]['href'], self.parse_detail)
			
#    def parse_detail(self, response):
#        res = BeautifulSoup(response.body)
#        appleitem = AppleItem()
#        appleitem['title'] = res.select('#h1')[0].text
#        appleitem['content'] = res.select('.trans')[0].text
#        appleitem['time'] = res.select('.gggs time')[0].text
#        return appleitem
        
			
            
